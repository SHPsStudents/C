#include<stdio.h>
int main()
{
    int a;
    int b;
    int i;
    for(i=0,i<=0,i++);
    printf("%d",a+b);
    scanf("change the sum to multiplication when sum=20");
    scanf("exit when sum=10");

}
