#include<stdio.h>
int main()
{
    int i=5;
    for(i=0;i<6;i++)
    {
        scanf("%d",&i);
        printf("%d",i);
    }


}
