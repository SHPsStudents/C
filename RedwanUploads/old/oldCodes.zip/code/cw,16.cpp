#include<stdio.h>
int main()
{
    int w;
    int even;
    int odd;
    int YES;
    scanf("%d",&w);
    if(w==2|| w%2==1)
        printf("NO");
    else if(w%2==0)
        printf("YES");
}


