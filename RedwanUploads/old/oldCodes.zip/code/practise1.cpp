#include<stdio.h>
int main()
{
    int i,x;
    for(i=2;i>=0;i--)
    {
        for(x=0;x<3;x++)
        {
            printf("%d,%d\n",i,x);
         }
     }
}
