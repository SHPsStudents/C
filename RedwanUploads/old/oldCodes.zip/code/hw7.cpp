#include<stdio.h>
int main()
{
    int i;
    int ar[]=(2,6,9);
    int ar1[]=(6,2,8);
    for(i=0;i<3,i++)
    {
        for()
    }
}
