#include<stdio.h>
#include <string.h>
int main()
{
    char ar[101];
    scanf("%s",&ar);
    int len  = strlen(ar);
    printf("%d %s\n",len,ar);

}
