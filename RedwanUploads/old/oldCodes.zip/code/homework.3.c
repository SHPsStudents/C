#include<stdio.h>
int main()
{
    int a;
    int b;
    int i;
    scanf("%d %d",a,b);
    for(i=0,i>=0,i++)
    {
        if(i==10)
            break;
    }
     scanf("exit when sum is 10");
     printf("%d",a+b);
    }





