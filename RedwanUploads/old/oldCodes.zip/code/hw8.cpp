#include<stdio.h>
int main()
{
    int i;
    for(i=3;i>=0;i--)
    {
        for(int x=0;x<=3;x++)
            printf("%d %d\n,i,x");
    }
}
