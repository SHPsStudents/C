#include<stdio.h>
int main()
{
   int n =4;
   int k;
   for(int stars=1;stars=stars++)
   {
       for( k=0;k<stars;k++)
            printf("1");
   }
                printf("\n");

}
