#include<stdio.h>
int main()
{
    int sum=0;
    int i;
    while(i>=1 )
    {
        sum=(sum+i);
        i--;
    }
    printf("%d",sum);
}
