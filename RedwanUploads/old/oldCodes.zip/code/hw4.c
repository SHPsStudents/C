#Include<stdio.h>
int main()
{
    int n=4;
    int max number=n*2-1;
    for(int i=1;i<=4;i++)
    {
        int space=(max number-i*2-1)/2;
        for(int j=0;j<space;j++)
            printf(" ");
        printf(totalnumber=i*2-1);
        for(intk=0;k<total number;j++)
        {
            printf("%d",number)
            number++;
        }
    }   printf(" ");
}
