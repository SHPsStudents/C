#include<stdio.h>
int main()
{
    int m,n;
    scanf("%d %d",&m,&n);
    int a=2;
    int ans=0;
    ans=m*n/a;
    printf("%d",ans);
}
