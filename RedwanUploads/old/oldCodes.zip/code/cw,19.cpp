#include<stdio.h>
int main()
{
    char stn[4];
    for(int n=1;n<=4;n++)
    {
        scanf("%s",&stn);
        printf("%s",stn);
    }


}
