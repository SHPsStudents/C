#include<stdio.h>
function
int add(int a,int b)
    return(int a+int b);
int main()
{
    int a;
    int b;
    scanf("%d %d",&a,&b);
    printf ("%d\n",a+b);
}
